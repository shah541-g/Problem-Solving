What this code does:
It counts how many unique characters are present in the input string.
For the string "Alai", the unique characters are 'A', 'l', and 'i' → so it returns 3.

Working of the Function:
duplicated = []
A list used to keep track of all characters that have been seen so far.
Looping through each character in the input string str:
If the character has not already been seen (i.e., it's not in duplicated), then it is counted as a unique character → count += 1.
The character is then added to the duplicated list regardless.
Finally, the count of unique characters is returned.

Technique Used:
Manual tracking using a list to avoid using built-in set() for uniqueness.
The method **contains**() is used to check if the character is already present in the list (though normally we use in for readability: if c not in duplicated).
The logic here only tracks how many characters are unique in the string.

Incomplete Logic:
Your function currently does not handle or count characters that appear more than once separately.
If your goal is to also count duplicated characters or return both unique and duplicate counts, that part is missing.

Time Complexity:
the time complexity of this task os O(n^2)

Missing Part (To be Added):
You may want to count how many characters are duplicated (i.e., appear more than once).
This could be done using a dictionary or additional logic to track frequencies.
