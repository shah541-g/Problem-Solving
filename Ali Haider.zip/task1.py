def uniqueCount(str):
  duplicated = []
  count = 0
  for c in str:
    if not duplicated.__contains__(c):
      count = count + 1  
    duplicated.append(c)
  return count

print(uniqueCount("Alai"))